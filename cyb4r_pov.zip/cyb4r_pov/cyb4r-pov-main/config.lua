-- Polecenie, które przełącza POV
Config.CommandName = "pov"

-- Pole widzenia kamery
Config.CamFOV = 80.0

-- Przesunięcie kamery w stosunku do ciała gracza
Config.CamOffsetX = 0.05
Config.CamOffsetY = 0.05
Config.CamOffsetZ = 0.15

-- Kamera odsunięta od ciała gracza podczas cofania w pojeździe i przytrzymania C (kamera cofania)
Config.ReverseCamOffsetX = -0.29
Config.ReverseCamOffsetY = -0.29
Config.ReverseCamOffsetZ = 0.2
