fx_version 'bodacious'
game 'gta5'

author 'Cyb4r'
description 'POV Script'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependencies {
    'es_extended'
}
