local povEnabled = false
local cam = nil

local function setFirstPersonPOV()
    povEnabled = true
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
    SetCamCoord(cam, playerCoords.x + Config.CamOffsetX, playerCoords.y + Config.CamOffsetY, playerCoords.z + Config.CamOffsetZ)
    SetCamRot(cam, GetEntityRotation(playerPed))
    SetCamFov(cam, Config.CamFOV)
    SetCamActive(cam, true)
    RenderScriptCams(true, false, 0, true, true)
    
    SetPedResetFlag(playerPed, 322, true)
    SetPedConfigFlag(playerPed, 438, true)
    SetPedConfigFlag(playerPed, 439, true)

    ESX.ShowNotification("~g~~h~POV został włączony")
end

local function setThirdPersonPOV()
    povEnabled = false

    if cam then
        RenderScriptCams(false, false, 0, true, true)
        DestroyCam(cam, false)
        cam = nil
    end

    local playerPed = PlayerPedId()
    SetPedConfigFlag(playerPed, 438, false)
    SetPedConfigFlag(playerPed, 439, false)

    ESX.ShowNotification("~r~~h~POV został wyłączony")
end

local function togglePOV()
    if povEnabled then
        setThirdPersonPOV()
    else
        setFirstPersonPOV()
    end
end

local function updateVehiclePOV()
    if povEnabled and IsPedInAnyVehicle(PlayerPedId(), false) then
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if vehicle then
            local playerCoords = GetEntityCoords(PlayerPedId())
            SetCamCoord(cam, playerCoords.x + Config.CamOffsetX, playerCoords.y + Config.CamOffsetY, playerCoords.z + Config.CamOffsetZ)
            SetCamRot(cam, GetEntityRotation(PlayerPedId()))
        end
    end
end

RegisterCommand(Config.CommandName, function(source, args, rawCommand)
    togglePOV()
end, false)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if povEnabled then
            if IsPedInAnyVehicle(PlayerPedId(), false) then
                updateVehiclePOV()
            else
                local playerCoords = GetEntityCoords(PlayerPedId())
                SetCamCoord(cam, playerCoords.x + Config.CamOffsetX, playerCoords.y + Config.CamOffsetY, playerCoords.z + Config.CamOffsetZ)
                SetCamRot(cam, GetEntityRotation(PlayerPedId()))
            end
        end
    end
end)

AddEventHandler('onClientMapStart', function()
    print("Skrypt POV został załadowany.")
end)
